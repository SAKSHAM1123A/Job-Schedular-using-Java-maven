# Job Scheduler

A small desktop job scheduler built with Java 21, Maven, and Swing. Create jobs with a name, an action/message, a delay of up to 24 hours, and a priority. The scheduler records the action in its activity bar when the delay expires. Jobs with the same scheduled time run in priority order; jobs at the same priority run in the order they were added.

## Requirements

- JDK 21 or later
- Maven 3.8 or later

Maven must run with JDK 21 or later; verify the active version with `mvn -version`.

## Run

From the project folder:

```powershell
mvn clean compile
mvn exec:java
```

Select a job in the list to use **Run now**, **Cancel pending**, or **Delete selected**. Deleting removes the job from the list; if it is still pending, it is also cancelled. A job that is already running cannot be interrupted, but it can still be removed from the list.


## Updated interface

The Swing interface now includes:
- A dashboard with total, pending, completed, and failed job counters.
- A cleaner job creation panel with priority and delay controls.
- A searchable jobs table with coloured status text.
- Run now, cancel pending, and delete selected actions.
- A timestamped activity log.

The scheduler queue and worker-thread implementation are retained.

## Database (SQLite)

Jobs and the activity log are stored in a local SQLite file (`chronos.db`), so they survive restarts. Pending jobs are re-queued on startup (overdue ones run immediately).

No database server is needed. The file and its tables (`jobs`, `activity_log`; see `src/main/resources/schema.sql`) are created automatically in the folder you run the app from. To use a different location, change `db.path` in `src/main/resources/db.properties` or set the `CHRONOS_DB_PATH` environment variable.

If the database cannot be opened, the app warns you and runs in memory only.
