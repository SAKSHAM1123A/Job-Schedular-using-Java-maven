CREATE TABLE IF NOT EXISTS jobs (
    id            TEXT PRIMARY KEY,
    name          TEXT NOT NULL,
    action        TEXT NOT NULL,
    priority      TEXT NOT NULL CHECK (priority IN ('LOW','NORMAL','HIGH','URGENT')),
    status        TEXT NOT NULL CHECK (status IN ('PENDING','RUNNING','COMPLETED','CANCELLED','FAILED')),
    result        TEXT,
    created_at    TEXT NOT NULL,
    scheduled_for TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_jobs_status_scheduled ON jobs (status, scheduled_for);

CREATE TABLE IF NOT EXISTS activity_log (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    logged_at TEXT NOT NULL,
    message   TEXT NOT NULL
)
