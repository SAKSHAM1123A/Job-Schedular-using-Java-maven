package com.jobscheduler;

import java.time.Instant;
import java.util.UUID;

public final class Job {
    private final UUID id;
    private final String name;
    private final String action;
    private final JobPriority priority;
    private final Instant createdAt;
    private final Instant scheduledFor;
    private volatile JobStatus status = JobStatus.PENDING;
    private volatile String result = "";

    public Job(String name, String action, JobPriority priority, Instant scheduledFor) {
        this(UUID.randomUUID(), name, action, priority, Instant.now(), scheduledFor, JobStatus.PENDING, "");
    }

    /** Restores a job loaded from the database. */
    public Job(UUID id, String name, String action, JobPriority priority, Instant createdAt,
               Instant scheduledFor, JobStatus status, String result) {
        this.id = id;
        this.createdAt = createdAt;
        this.status = status;
        this.result = result == null ? "" : result;
        this.name = name;
        this.action = action;
        this.priority = priority;
        this.scheduledFor = scheduledFor;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAction() {
        return action;
    }

    public JobPriority getPriority() {
        return priority;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getScheduledFor() {
        return scheduledFor;
    }

    public JobStatus getStatus() {
        return status;
    }

    public String getResult() {
        return result;
    }

    void setStatus(JobStatus status) {
        this.status = status;
    }

    void setResult(String result) {
        this.result = result;
    }
}
