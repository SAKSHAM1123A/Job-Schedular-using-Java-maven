package com.jobscheduler;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/** Loads the SQLite file location and creates the schema on first run. */
public final class Database {
    private final String url;

    public Database() {
        Properties props = new Properties();
        try (InputStream in = Database.class.getResourceAsStream("/db.properties")) {
            if (in != null) {
                props.load(in);
            }
        } catch (IOException ignored) {
        }
        String path = System.getenv("CHRONOS_DB_PATH");
        if (path == null || path.isBlank()) {
            path = props.getProperty("db.path", "chronos.db");
        }
        url = "jdbc:sqlite:" + path;
    }

    public Connection connect() throws SQLException {
        Connection connection = DriverManager.getConnection(url);
        try (Statement s = connection.createStatement()) {
            s.execute("PRAGMA busy_timeout = 5000");
        }
        return connection;
    }

    /** Creates the tables if they do not exist. */
    public void initSchema() throws SQLException {
        String sql;
        try (InputStream in = Database.class.getResourceAsStream("/schema.sql")) {
            if (in == null) {
                throw new SQLException("schema.sql not found on the classpath");
            }
            sql = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new SQLException("Could not read schema.sql", e);
        }
        try (Connection c = connect(); Statement s = c.createStatement()) {
            for (String statement : sql.split(";")) {
                if (!statement.isBlank()) {
                    s.execute(statement);
                }
            }
        }
    }
}
