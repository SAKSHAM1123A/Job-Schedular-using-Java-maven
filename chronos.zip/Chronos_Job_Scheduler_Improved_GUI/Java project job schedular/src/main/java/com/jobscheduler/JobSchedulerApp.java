package com.jobscheduler;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableRowSorter;

public final class JobSchedulerApp {
    private JobSchedulerApp() {
    }

    private static final Color BACKGROUND = new Color(245, 247, 251);
    private static final Color NAVY = new Color(20, 32, 55);
    private static final Color BLUE = new Color(55, 105, 210);
    private static final Color TEXT = new Color(40, 52, 70);
    private static final Color MUTED = new Color(115, 126, 145);
    private static final Color BORDER = new Color(225, 230, 238);

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            new SchedulerWindow().show();
        });
    }

    private static final class SchedulerWindow {
        private final JobTableModel tableModel = new JobTableModel();
        private final JTextField nameField = new JTextField();
        private final JTextField actionField = new JTextField();
        private final JSpinner delaySpinner = new JSpinner(new SpinnerNumberModel(10, 0, 99999999, 1));
        private final JComboBox<JobPriority> priorityBox = new JComboBox<>(JobPriority.values());
        private final JTextField searchField = new JTextField(18);
        private final JTextArea activityArea = new JTextArea(5, 30);
        private final JLabel totalValue = new JLabel("0");
        private final JLabel pendingValue = new JLabel("0");
        private final JLabel completedValue = new JLabel("0");
        private final JLabel failedValue = new JLabel("0");
        private JTable jobsTable;
        private TableRowSorter<JobTableModel> sorter;
        private JFrame frame;

        // Database persistence. repository stays null if the database cannot be opened (app then runs in memory only).
        private volatile JobRepository repository;
        private final ExecutorService dbExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "chronos-db-writer");
            t.setDaemon(true);
            return t;
        });

        private final JobQueue jobQueue = new JobQueue(job -> {
            persist(() -> repository.save(job));
            SwingUtilities.invokeLater(() -> {
                tableModel.refresh(job);
                updateDashboard();
                log(job.getStatus() + "  •  " + job.getName() + " — " + job.getResult());
            });
        });

        private interface DbTask {
            void run() throws Exception;
        }

        /** Runs a database write on the background thread; failures go to the activity log, not the UI thread. */
        private void persist(DbTask task) {
            if (repository == null) return;
            dbExecutor.execute(() -> {
                try {
                    task.run();
                } catch (Exception e) {
                    SwingUtilities.invokeLater(() -> log("DB ERROR  •  " + e.getMessage()));
                }
            });
        }

        private void initDatabase() {
            try {
                Database database = new Database();
                database.initSchema();
                JobRepository repo = new JobRepository(database);
                for (String line : repo.recentActivity(100)) {
                    activityArea.append(line + "\n");
                }
                List<Job> saved = repo.findAll();
                repository = repo; // set before scheduling so overdue jobs persist their results
                for (Job job : saved) {
                    if (job.getStatus() == JobStatus.RUNNING) {
                        // The app closed mid-run; put it back in the queue.
                        job = new Job(job.getId(), job.getName(), job.getAction(), job.getPriority(),
                                job.getCreatedAt(), job.getScheduledFor(), JobStatus.PENDING, "");
                    }
                    tableModel.add(job);
                    if (job.getStatus() == JobStatus.PENDING) {
                        jobQueue.schedule(job); // overdue jobs run immediately
                    }
                }
                log("DATABASE  •  opened, loaded " + tableModel.jobs.size() + " job(s)");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(frame,
                        "Could not open the SQLite database, so jobs will NOT be saved this session.\n\n" + e.getMessage()
                                + "\n\nCheck the db.path setting in src/main/resources/db.properties (or the CHRONOS_DB_PATH environment variable).",
                        "Database unavailable", JOptionPane.WARNING_MESSAGE);
            }
        }

        private void show() {
            frame = new JFrame("Chronos | Job Scheduler");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setMinimumSize(new Dimension(1000, 680));
            frame.setSize(1200, 780);
            frame.setLocationRelativeTo(null);
            frame.getContentPane().setBackground(BACKGROUND);
            frame.setLayout(new BorderLayout(0, 0));

            frame.add(createHeader(), BorderLayout.NORTH);
            frame.add(createMainContent(), BorderLayout.CENTER);
            frame.add(createActivityPanel(), BorderLayout.SOUTH);
            frame.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent event) {
                    jobQueue.close();
                    dbExecutor.shutdown();
                    try {
                        dbExecutor.awaitTermination(3, java.util.concurrent.TimeUnit.SECONDS);
                    } catch (InterruptedException ignored) {
                        Thread.currentThread().interrupt();
                    }
                }
            });

            frame.setVisible(true);
            initDatabase();
            updateDashboard();
        }

        private JPanel createHeader() {
            JPanel header = new JPanel(new BorderLayout());
            header.setBackground(NAVY);
            header.setBorder(BorderFactory.createEmptyBorder(22, 30, 22, 30));

            JPanel titlePanel = new JPanel(new BorderLayout(0, 5));
            titlePanel.setOpaque(false);
            JLabel title = new JLabel("CHRONOS");
            title.setForeground(Color.WHITE);
            title.setFont(new Font("Segoe UI", Font.BOLD, 25));
            JLabel subtitle = new JLabel("JOB SCHEDULER MANAGEMENT SYSTEM");
            subtitle.setForeground(new Color(184, 197, 220));
            subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            titlePanel.add(title, BorderLayout.NORTH);
            titlePanel.add(subtitle, BorderLayout.SOUTH);

            header.add(titlePanel, BorderLayout.WEST);
            return header;
        }

        private JPanel createMainContent() {
            JPanel content = new JPanel(new BorderLayout(18, 18));
            content.setBackground(BACKGROUND);
            content.setBorder(BorderFactory.createEmptyBorder(20, 24, 12, 24));
            content.add(createStatsPanel(), BorderLayout.NORTH);

            JPanel workspace = new JPanel(new BorderLayout(18, 0));
            workspace.setOpaque(false);
            workspace.add(createFormPanel(), BorderLayout.WEST);
            workspace.add(createJobsPanel(), BorderLayout.CENTER);
            content.add(workspace, BorderLayout.CENTER);
            return content;
        }

        private JPanel createStatsPanel() {
            JPanel stats = new JPanel(new java.awt.GridLayout(1, 4, 14, 0));
            stats.setOpaque(false);
            stats.add(statCard("TOTAL JOBS", totalValue, new Color(55, 105, 210)));
            stats.add(statCard("PENDING", pendingValue, new Color(215, 151, 45)));
            stats.add(statCard("COMPLETED", completedValue, new Color(37, 157, 105)));
            stats.add(statCard("FAILED", failedValue, new Color(205, 75, 82)));
            return stats;
        }

        private JPanel statCard(String caption, JLabel value, Color accent) {
            JPanel card = new JPanel(new BorderLayout(0, 8));
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 4, 0, 0, accent),
                    BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(BORDER),
                            BorderFactory.createEmptyBorder(13, 16, 13, 16))));
            JLabel label = new JLabel(caption);
            label.setForeground(MUTED);
            label.setFont(new Font("Segoe UI", Font.BOLD, 10));
            value.setForeground(NAVY);
            value.setFont(new Font("Segoe UI", Font.BOLD, 25));
            card.add(label, BorderLayout.NORTH);
            card.add(value, BorderLayout.CENTER);
            return card;
        }

        private JPanel createFormPanel() {
            JPanel panel = new JPanel(new GridBagLayout());
            panel.setBackground(Color.WHITE);
            panel.setPreferredSize(new Dimension(300, 0));
            panel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER),
                    BorderFactory.createEmptyBorder(18, 18, 18, 18)));

            GridBagConstraints c = new GridBagConstraints();
            c.gridx = 0;
            c.gridy = 0;
            c.weightx = 1;
            c.fill = GridBagConstraints.HORIZONTAL;
            c.anchor = GridBagConstraints.WEST;
            c.insets = new Insets(0, 0, 8, 0);

            JLabel heading = new JLabel("Create new job");
            heading.setFont(new Font("Segoe UI", Font.BOLD, 18));
            heading.setForeground(NAVY);
            panel.add(heading, c);

            c.gridy++;
            c.insets = new Insets(0, 0, 18, 0);
            JLabel hint = new JLabel("Add a task to the execution queue");
            hint.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            hint.setForeground(MUTED);
            panel.add(hint, c);

            addField(panel, c, "JOB NAME", nameField);
            addField(panel, c, "ACTION / MESSAGE", actionField);
            addField(panel, c, "PRIORITY", priorityBox);
            addField(panel, c, "DELAY (SECONDS)", delaySpinner);

            c.gridy++;
            c.weighty = 1;
            panel.add(new JPanel() {{ setOpaque(false); }}, c);

            JButton scheduleButton = primaryButton("+  Schedule job");
            scheduleButton.addActionListener(e -> scheduleJob());
            c.gridy++;
            c.weighty = 0;
            c.insets = new Insets(10, 0, 0, 0);
            panel.add(scheduleButton, c);

            JLabel note = new JLabel("<html><div style='width:235px'>Jobs are processed automatically when their delay expires. Higher priority jobs run first when scheduled times match.</div></html>");
            note.setForeground(MUTED);
            note.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            c.gridy++;
            c.insets = new Insets(14, 0, 0, 0);
            panel.add(note, c);
            return panel;
        }

        private void addField(JPanel panel, GridBagConstraints c, String labelText, JComponent input) {
            c.gridy++;
            c.insets = new Insets(0, 0, 6, 0);
            JLabel label = new JLabel(labelText);
            label.setForeground(MUTED);
            label.setFont(new Font("Segoe UI", Font.BOLD, 10));
            panel.add(label, c);

            c.gridy++;
            c.insets = new Insets(0, 0, 13, 0);
            input.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            input.setPreferredSize(new Dimension(240, 36));
            if (input instanceof JTextField field) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER),
                        BorderFactory.createEmptyBorder(7, 9, 7, 9)));
            }
            panel.add(input, c);
        }

        private JPanel createJobsPanel() {
            JPanel panel = new JPanel(new BorderLayout(0, 12));
            panel.setBackground(Color.WHITE);
            panel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER),
                    BorderFactory.createEmptyBorder(16, 16, 14, 16)));

            JPanel top = new JPanel(new BorderLayout(10, 8));
            top.setOpaque(false);
            JLabel heading = new JLabel("Scheduled jobs");
            heading.setFont(new Font("Segoe UI", Font.BOLD, 18));
            heading.setForeground(NAVY);
            top.add(heading, BorderLayout.WEST);

            searchField.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            searchField.setToolTipText("Search jobs by name, action, priority or status");
            searchField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER),
                    BorderFactory.createEmptyBorder(7, 9, 7, 9)));
            top.add(searchField, BorderLayout.EAST);
            panel.add(top, BorderLayout.NORTH);

            jobsTable = new JTable(tableModel);
            jobsTable.setRowHeight(36);
            jobsTable.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            jobsTable.setForeground(TEXT);
            jobsTable.setBackground(Color.WHITE);
            jobsTable.setGridColor(new Color(239, 242, 247));
            jobsTable.setShowVerticalLines(false);
            jobsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            jobsTable.setFillsViewportHeight(true);
            jobsTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 10));
            jobsTable.getTableHeader().setForeground(MUTED);
            jobsTable.getTableHeader().setBackground(new Color(247, 249, 252));
            jobsTable.getTableHeader().setPreferredSize(new Dimension(0, 34));
            jobsTable.setSelectionBackground(new Color(229, 238, 255));
            jobsTable.setSelectionForeground(NAVY);
            jobsTable.setDefaultRenderer(Object.class, new JobCellRenderer());
            sorter = new TableRowSorter<>(tableModel);
            jobsTable.setRowSorter(sorter);

            searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
                private void filter() {
                    String text = searchField.getText().trim();
                    sorter.setRowFilter(text.isEmpty() ? null : RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(text)));
                }
                public void insertUpdate(javax.swing.event.DocumentEvent e) { filter(); }
                public void removeUpdate(javax.swing.event.DocumentEvent e) { filter(); }
                public void changedUpdate(javax.swing.event.DocumentEvent e) { filter(); }
            });

            JScrollPane scroll = new JScrollPane(jobsTable);
            scroll.setBorder(BorderFactory.createLineBorder(BORDER));
            panel.add(scroll, BorderLayout.CENTER);
            panel.add(createActionBar(), BorderLayout.SOUTH);
            return panel;
        }

        private JPanel createActionBar() {
            JPanel bar = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 8, 8));
            bar.setOpaque(false);
            JButton run = secondaryButton("Run now");
            JButton cancel = secondaryButton("Cancel pending");
            JButton delete = dangerButton("Delete selected");
            run.addActionListener(e -> runSelectedNow());
            cancel.addActionListener(e -> cancelSelected());
            delete.addActionListener(e -> deleteSelected());
            bar.add(run);
            bar.add(cancel);
            bar.add(delete);
            return bar;
        }

        private JPanel createActivityPanel() {
            JPanel panel = new JPanel(new BorderLayout(0, 8));
            panel.setBackground(BACKGROUND);
            panel.setBorder(BorderFactory.createEmptyBorder(0, 24, 18, 24));
            JLabel heading = new JLabel("ACTIVITY LOG");
            heading.setForeground(MUTED);
            heading.setFont(new Font("Segoe UI", Font.BOLD, 10));
            activityArea.setEditable(false);
            activityArea.setLineWrap(true);
            activityArea.setWrapStyleWord(true);
            activityArea.setFont(new Font("Consolas", Font.PLAIN, 11));
            activityArea.setForeground(new Color(218, 228, 243));
            activityArea.setBackground(new Color(29, 42, 66));
            activityArea.setBorder(BorderFactory.createEmptyBorder(9, 12, 9, 12));
            JScrollPane scroll = new JScrollPane(activityArea);
            scroll.setBorder(BorderFactory.createEmptyBorder());
            scroll.setPreferredSize(new Dimension(0, 95));
            panel.add(heading, BorderLayout.NORTH);
            panel.add(scroll, BorderLayout.CENTER);
            return panel;
        }

        private JButton primaryButton(String text) {
            JButton button = new JButton(text);
            button.setBackground(BLUE);
            button.setForeground(Color.WHITE);
            button.setOpaque(true);
            button.setContentAreaFilled(true);
            button.setBorderPainted(false);
            button.setFocusPainted(false);
            button.setFont(new Font("Segoe UI", Font.BOLD, 12));
            button.setBorder(BorderFactory.createEmptyBorder(11, 14, 11, 14));
            button.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
            return button;
        }

        private JButton secondaryButton(String text) {
            JButton button = new JButton(text);
            button.setBackground(new Color(239, 244, 255));
            button.setForeground(BLUE);
            button.setFocusPainted(false);
            button.setFont(new Font("Segoe UI", Font.BOLD, 11));
            button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(215, 226, 248)),
                    BorderFactory.createEmptyBorder(8, 12, 8, 12)));
            return button;
        }

        private JButton dangerButton(String text) {
            JButton button = secondaryButton(text);
            button.setBackground(new Color(255, 241, 241));
            button.setForeground(new Color(190, 64, 70));
            button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(246, 216, 216)),
                    BorderFactory.createEmptyBorder(8, 12, 8, 12)));
            return button;
        }

        private void scheduleJob() {
            String name = nameField.getText().trim();
            String action = actionField.getText().trim();
            if (name.isEmpty() || action.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter both a job name and an action/message.",
                        "Missing information", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int delay = (Integer) delaySpinner.getValue();
            Instant scheduledFor = Instant.now().plusSeconds(delay);
            Job job = new Job(name, action, (JobPriority) priorityBox.getSelectedItem(), scheduledFor);
            try {
                jobQueue.schedule(job);
                persist(() -> repository.save(job));
                tableModel.add(job);
                updateDashboard();
                log("SCHEDULED  •  " + name + "  •  " + delay + " sec  •  " + job.getPriority());
                nameField.setText("");
                actionField.setText("");
                nameField.requestFocus();
            } catch (IllegalStateException exception) {
                JOptionPane.showMessageDialog(frame, exception.getMessage(), "Scheduler error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }

        private void runSelectedNow() {
            Job job = selectedJob();
            if (job == null) return;
            if (job.getStatus() != JobStatus.PENDING || !jobQueue.cancel(job)) {
                JOptionPane.showMessageDialog(frame, "Only pending jobs can be run immediately.",
                        "Job unavailable", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            int row = tableModel.indexOf(job);
            Job immediate = new Job(job.getName(), job.getAction(), job.getPriority(), Instant.now());
            tableModel.replace(row, immediate);
            persist(() -> {
                repository.delete(job.getId());
                repository.save(immediate);
            });
            jobQueue.schedule(immediate);
            updateDashboard();
            log("RUN NOW  •  " + job.getName());
        }

        private void cancelSelected() {
            Job job = selectedJob();
            if (job == null) return;
            if (jobQueue.cancel(job)) {
                persist(() -> repository.save(job));
                tableModel.refresh(job);
                updateDashboard();
                log("CANCELLED  •  " + job.getName());
            } else {
                JOptionPane.showMessageDialog(frame, "Only pending jobs can be cancelled.",
                        "Job unavailable", JOptionPane.INFORMATION_MESSAGE);
            }
        }

        private void deleteSelected() {
            Job job = selectedJob();
            if (job == null) return;
            jobQueue.cancel(job);
            persist(() -> repository.delete(job.getId()));
            tableModel.remove(job);
            updateDashboard();
            log("DELETED  •  " + job.getName());
        }

        private Job selectedJob() {
            int row = jobsTable.getSelectedRow();
            return row < 0 ? null : tableModel.getJob(jobsTable.convertRowIndexToModel(row));
        }

        private void updateDashboard() {
            int total = tableModel.jobs.size();
            int pending = 0, completed = 0, failed = 0;
            for (Job job : tableModel.jobs) {
                if (job.getStatus() == JobStatus.PENDING || job.getStatus() == JobStatus.RUNNING) pending++;
                if (job.getStatus() == JobStatus.COMPLETED) completed++;
                if (job.getStatus() == JobStatus.FAILED) failed++;
            }
            totalValue.setText(String.valueOf(total));
            pendingValue.setText(String.valueOf(pending));
            completedValue.setText(String.valueOf(completed));
            failedValue.setText(String.valueOf(failed));
        }

        private void log(String message) {
            String time = DateTimeFormatter.ofPattern("HH:mm:ss")
                    .withZone(ZoneId.systemDefault()).format(Instant.now());
            activityArea.append("[" + time + "]  " + message + "\n");
            if (!message.startsWith("DB ERROR")) {
                Instant now = Instant.now();
                persist(() -> repository.logActivity(now, message));
            }
            activityArea.setCaretPosition(activityArea.getDocument().getLength());
        }
    }

    private static final class JobCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean selected,
                                                       boolean focused, int row, int column) {
            Component component = super.getTableCellRendererComponent(table, value, selected, focused, row, column);
            setBorder(BorderFactory.createEmptyBorder(0, 9, 0, 9));
            if (!selected) {
                setBackground(Color.WHITE);
                setForeground(TEXT);
            }
            if (column == 4 && value != null && !selected) {
                String status = value.toString();
                if (status.equals("COMPLETED")) setForeground(new Color(29, 145, 95));
                else if (status.equals("FAILED")) setForeground(new Color(195, 65, 72));
                else if (status.equals("PENDING")) setForeground(new Color(190, 130, 30));
                else if (status.equals("CANCELLED")) setForeground(MUTED);
                setFont(new Font("Segoe UI", Font.BOLD, 10));
            } else {
                setFont(new Font("Segoe UI", Font.PLAIN, 11));
            }
            return component;
        }
    }

    private static final class JobTableModel extends AbstractTableModel {
        private static final String[] COLUMNS = {"Job name", "Action / message", "Priority", "Scheduled for", "Status"};
        private static final DateTimeFormatter TIME_FORMAT =
                DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm:ss").withZone(ZoneId.systemDefault());
        private final List<Job> jobs = new ArrayList<>();

        public int getRowCount() { return jobs.size(); }
        public int getColumnCount() { return COLUMNS.length; }
        public String getColumnName(int column) { return COLUMNS[column]; }

        public Object getValueAt(int row, int column) {
            Job job = jobs.get(row);
            return switch (column) {
                case 0 -> job.getName();
                case 1 -> job.getAction();
                case 2 -> job.getPriority();
                case 3 -> TIME_FORMAT.format(job.getScheduledFor());
                case 4 -> job.getStatus();
                default -> "";
            };
        }

        private void add(Job job) {
            jobs.add(job);
            fireTableRowsInserted(jobs.size() - 1, jobs.size() - 1);
        }
        private Job getJob(int row) { return jobs.get(row); }
        private int indexOf(Job job) { return jobs.indexOf(job); }
        private void replace(int row, Job job) {
            jobs.set(row, job);
            fireTableRowsUpdated(row, row);
        }
        private void remove(Job job) {
            int row = jobs.indexOf(job);
            if (row >= 0) {
                jobs.remove(row);
                fireTableRowsDeleted(row, row);
            }
        }
        private void refresh(Job job) {
            int row = jobs.indexOf(job);
            if (row >= 0) fireTableRowsUpdated(row, row);
        }
    }
}
