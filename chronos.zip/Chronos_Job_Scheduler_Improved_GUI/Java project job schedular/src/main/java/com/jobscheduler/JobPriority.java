package com.jobscheduler;

public enum JobPriority {
    LOW(1),
    NORMAL(2),
    HIGH(3),
    URGENT(4);

    private final int rank;

    JobPriority(int rank) {
        this.rank = rank;
    }

    public int getRank() {
        return rank;
    }
}
