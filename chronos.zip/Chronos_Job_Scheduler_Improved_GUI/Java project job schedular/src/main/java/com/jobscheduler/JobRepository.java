package com.jobscheduler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** All SQL for jobs and the activity log (SQLite). */
public final class JobRepository {
    private final Database database;

    public JobRepository(Database database) {
        this.database = database;
    }

    // Timestamps are stored as ISO-8601 UTC text, e.g. 2026-10-30T06:45:12.123Z
    private static String toDb(Instant instant) {
        return instant.toString();
    }

    private static Instant fromDb(String value) {
        return Instant.parse(value);
    }

    /** Inserts the job, or updates its status/result if it already exists. */
    public void save(Job job) throws SQLException {
        String sql = """
                INSERT INTO jobs (id, name, action, priority, status, result, created_at, scheduled_for)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET status = excluded.status, result = excluded.result
                """;
        try (Connection c = database.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, job.getId().toString());
            ps.setString(2, job.getName());
            ps.setString(3, job.getAction());
            ps.setString(4, job.getPriority().name());
            ps.setString(5, job.getStatus().name());
            ps.setString(6, job.getResult());
            ps.setString(7, toDb(job.getCreatedAt()));
            ps.setString(8, toDb(job.getScheduledFor()));
            ps.executeUpdate();
        }
    }

    public void delete(UUID id) throws SQLException {
        try (Connection c = database.connect();
             PreparedStatement ps = c.prepareStatement("DELETE FROM jobs WHERE id = ?")) {
            ps.setString(1, id.toString());
            ps.executeUpdate();
        }
    }

    public List<Job> findAll() throws SQLException {
        List<Job> jobs = new ArrayList<>();
        try (Connection c = database.connect();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM jobs ORDER BY created_at");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                jobs.add(new Job(
                        UUID.fromString(rs.getString("id")),
                        rs.getString("name"),
                        rs.getString("action"),
                        JobPriority.valueOf(rs.getString("priority")),
                        fromDb(rs.getString("created_at")),
                        fromDb(rs.getString("scheduled_for")),
                        JobStatus.valueOf(rs.getString("status")),
                        rs.getString("result")));
            }
        }
        return jobs;
    }

    public void logActivity(Instant at, String message) throws SQLException {
        try (Connection c = database.connect();
             PreparedStatement ps = c.prepareStatement("INSERT INTO activity_log (logged_at, message) VALUES (?, ?)")) {
            ps.setString(1, toDb(at));
            ps.setString(2, message.length() > 1000 ? message.substring(0, 1000) : message);
            ps.executeUpdate();
        }
    }

    /** Most recent entries, oldest first, for refilling the activity panel. */
    public List<String> recentActivity(int limit) throws SQLException {
        List<String> lines = new ArrayList<>();
        String sql = "SELECT logged_at, message FROM (SELECT * FROM activity_log ORDER BY id DESC LIMIT ?) t ORDER BY id";
        try (Connection c = database.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lines.add(rs.getString("logged_at") + "  " + rs.getString("message"));
                }
            }
        }
        return lines;
    }
}
