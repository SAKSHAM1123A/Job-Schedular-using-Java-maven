package com.jobscheduler;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;

public final class JobQueue implements AutoCloseable {
    private final DelayQueue<QueuedJob> queue = new DelayQueue<>();
    private final Map<Job, QueuedJob> queuedJobs = new ConcurrentHashMap<>();
    private final AtomicLong order = new AtomicLong();
    private final Consumer<Job> completionListener;
    private final Instant clockInstant = Instant.now();
    private final long clockNanos = System.nanoTime();
    private final Thread worker;
    private volatile boolean closed;

    public JobQueue(Consumer<Job> completionListener) {
        this.completionListener = completionListener;
        worker = new Thread(this::runWorker, "job-scheduler-worker");
        worker.setDaemon(true);
        worker.start();
    }

    public void schedule(Job job) {
        if (closed) {
            throw new IllegalStateException("The scheduler is closed.");
        }
        long dueNanos = clockNanos + Duration.between(clockInstant, job.getScheduledFor()).toNanos();
        QueuedJob queuedJob = new QueuedJob(job, dueNanos, order.getAndIncrement());
        queuedJobs.put(job, queuedJob);
        queue.put(queuedJob);
    }

    public boolean cancel(Job job) {
        QueuedJob queuedJob = queuedJobs.get(job);
        if (queuedJob == null) {
            return false;
        }
        synchronized (queuedJob) {
            if (job.getStatus() != JobStatus.PENDING) {
                return false;
            }
            job.setStatus(JobStatus.CANCELLED);
            queue.remove(queuedJob);
            queuedJobs.remove(job);
            return true;
        }
    }

    private void runWorker() {
        while (!closed) {
            try {
                QueuedJob queuedJob = queue.take();
                Job job = queuedJob.job;
                synchronized (queuedJob) {
                    if (job.getStatus() != JobStatus.PENDING) {
                        continue;
                    }
                    job.setStatus(JobStatus.RUNNING);
                }
                try {
                    job.setResult(job.getAction());
                    job.setStatus(JobStatus.COMPLETED);
                } catch (RuntimeException exception) {
                    job.setResult(exception.getMessage() == null ? exception.getClass().getSimpleName()
                            : exception.getMessage());
                    job.setStatus(JobStatus.FAILED);
                } finally {
                    queuedJobs.remove(job);
                    completionListener.accept(job);
                }
            } catch (InterruptedException exception) {
                if (!closed) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }
    }

    @Override
    public void close() {
        closed = true;
        worker.interrupt();
    }

    private static final class QueuedJob implements Delayed {
        private final Job job;
        private final long dueNanos;
        private final long order;

        private QueuedJob(Job job, long dueNanos, long order) {
            this.job = job;
            this.dueNanos = dueNanos;
            this.order = order;
        }

        @Override
        public long getDelay(TimeUnit unit) {
            return unit.convert(dueNanos - System.nanoTime(), TimeUnit.NANOSECONDS);
        }

        @Override
        public int compareTo(Delayed other) {
            QueuedJob that = (QueuedJob) other;
            int dueOrder = Long.compare(dueNanos, that.dueNanos);
            if (dueOrder != 0) {
                return dueOrder;
            }
            int priorityOrder = Integer.compare(that.job.getPriority().getRank(), job.getPriority().getRank());
            return priorityOrder != 0 ? priorityOrder : Long.compare(order, that.order);
        }
    }
}
