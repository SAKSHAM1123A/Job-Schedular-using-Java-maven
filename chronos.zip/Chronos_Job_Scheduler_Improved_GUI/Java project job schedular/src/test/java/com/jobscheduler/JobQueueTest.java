package com.jobscheduler;

import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class JobQueueTest {
    @Test
    void higherPriorityRunsFirstWhenJobsShareScheduledTime() throws InterruptedException {
        List<String> completed = new CopyOnWriteArrayList<>();
        CountDownLatch latch = new CountDownLatch(2);
        Instant scheduledFor = Instant.now().plusMillis(500);

        try (JobQueue queue = new JobQueue(job -> {
            completed.add(job.getName());
            latch.countDown();
        })) {
            queue.schedule(new Job("low", "low action", JobPriority.LOW, scheduledFor));
            queue.schedule(new Job("urgent", "urgent action", JobPriority.URGENT, scheduledFor));

            assertTrue(latch.await(3, TimeUnit.SECONDS), "Scheduled jobs did not complete in time.");
        }

        assertEquals(List.of("urgent", "low"), completed);
    }

    @Test
    void pendingJobCanBeCancelledBeforeItRuns() throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        Job job = new Job("cancelled", "action", JobPriority.NORMAL, Instant.now().plusSeconds(5));

        try (JobQueue queue = new JobQueue(ignored -> latch.countDown())) {
            queue.schedule(job);

            assertTrue(queue.cancel(job));
            assertEquals(JobStatus.CANCELLED, job.getStatus());
            assertTrue(!latch.await(200, TimeUnit.MILLISECONDS), "Cancelled job unexpectedly ran.");
        }
    }
}
